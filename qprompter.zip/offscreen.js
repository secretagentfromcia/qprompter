/**
 * Qprompter - Offscreen Document Script
 * Acts as a keepalive and heartbeat watchdog for the service worker.
 * NOTE: Offscreen documents have VERY limited Chrome API access.
 *       chrome.tabs is NOT available here — only chrome.storage and chrome.runtime.
 */

console.log("[Qprompter Offscreen] Context loaded.");

let watchdogInterval = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "OFFSCREEN_PING") {
    sendResponse({ ack: true, timestamp: Date.now() });
    return true;
  }

  if (message.type === "START_OFFSCREEN_MONITOR") {
    // FIX: Removed chrome.tabs.get() — tabs API is NOT available in offscreen documents.
    // Instead, we poll storage state only, which is available in offscreen contexts.
    startWatchdog(message.tabId);
    sendResponse({ started: true });
    return true;
  }

  if (message.type === "STOP_OFFSCREEN_MONITOR") {
    stopWatchdog();
    sendResponse({ stopped: true });
    return true;
  }
});

function startWatchdog(tabId) {
  stopWatchdog(); // Clear any existing watchdog first

  console.log("[Qprompter Offscreen] Watchdog started for tab:", tabId);

  watchdogInterval = setInterval(async () => {
    try {
      // FIX: Only read from storage (available in offscreen) — never call chrome.tabs
      const storage = await chrome.storage.local.get(["isNetworkStreaming", "status", "currentTabId"]);
      
      // Stop watchdog if queue is no longer running
      if (storage.status !== "RUNNING") {
        console.log("[Qprompter Offscreen] Queue stopped — halting watchdog.");
        stopWatchdog();
        return;
      }

      console.log(
        `[Qprompter Offscreen] Heartbeat — Status: ${storage.status}, Streaming: ${storage.isNetworkStreaming}`
      );
    } catch (err) {
      console.error("[Qprompter Offscreen] Watchdog error:", err.message);
    }
  }, 2000); // 2s interval — lightweight, not 1s
}

function stopWatchdog() {
  if (watchdogInterval) {
    clearInterval(watchdogInterval);
    watchdogInterval = null;
    console.log("[Qprompter Offscreen] Watchdog stopped.");
  }
}
