/**
 * Qprompter - Popup UI Coordinator
 * Manages tab navigation, list rendering, composers, file import, and messaging.
 */

document.addEventListener("DOMContentLoaded", () => {
  initializeTabs();
  syncFullUI();
  registerEventListeners();
  setInterval(syncTimerUI, 1000);
});

// ── State cache ───────────────────────────────────────────────────────────
let activeQueue    = [];
let activeLibrary  = [];
let activeHistory  = [];
let activeSettings = {};
let activeStatus   = "IDLE";

// ── Tab navigation ─────────────────────────────────────────────────────────
function initializeTabs() {
  const triggers = document.querySelectorAll(".tab-trigger");
  triggers.forEach(trigger => {
    trigger.addEventListener("click", () => {
      triggers.forEach(t => t.classList.remove("active"));
      trigger.classList.add("active");

      document.querySelectorAll(".tab-pane").forEach(pane => pane.classList.remove("active"));
      const pane = document.getElementById("pane-" + trigger.dataset.tab);
      if (pane) pane.classList.add("active");
    });
  });
}

// ── Full UI sync ───────────────────────────────────────────────────────────
function syncFullUI() {
  chrome.storage.local.get(["queue", "library", "history", "settings", "status"], (data) => {
    activeQueue    = data.queue    || [];
    activeLibrary  = data.library  || [];
    activeHistory  = data.history  || [];
    activeSettings = data.settings || {};
    activeStatus   = data.status   || "IDLE";

    document.body.classList.toggle("light-theme", !!activeSettings.lightTheme);

    renderQueueList();
    renderLibraryList();
    renderHistoryList();
    updateStatusDisplay();
    updateFooterStats();
    loadSettingsInputs();
  });
}

// ── Event registration ────────────────────────────────────────────────────
function registerEventListeners() {
  // Queue composer
  document.getElementById("btn-append-queue").addEventListener("click", appendNewPrompt);
  document.getElementById("btn-clear").addEventListener("click", clearQueue);

  // FIX: START button acts as RESUME when paused — sends the right action
  document.getElementById("btn-start").addEventListener("click", () => {
    if (activeStatus === "PAUSED") {
      triggerBackground("RESUME_QUEUE");
    } else {
      triggerBackground("START_QUEUE");
    }
  });
  document.getElementById("btn-pause").addEventListener("click", () => triggerBackground("PAUSE_QUEUE"));
  document.getElementById("btn-stop").addEventListener("click",  () => triggerBackground("STOP_QUEUE"));

  // Variable generator
  document.getElementById("btn-generator-add").addEventListener("click", generateVariablePrompts);

  // Image inspiration chips
  document.querySelectorAll("#insp-chips .chip").forEach(chip => {
    chip.addEventListener("click", () => {
      document.getElementById("inp-img-text").value = chip.dataset.text;
    });
  });
  document.getElementById("btn-add-img-queue").addEventListener("click", appendImagePrompt);

  // File import
  document.getElementById("inp-file-import").addEventListener("change", processTXTImportFile);

  // Webhook trigger
  document.getElementById("btn-trigger-webhook").addEventListener("click", executeWebhookTrigger);

  // Library search
  document.getElementById("inp-search-lib").addEventListener("input", searchLibraryTemplates);

  // History clear
  document.getElementById("btn-purge-history").addEventListener("click", clearHistoryLogs);

  // Settings — checkboxes
  const settingCheckboxes = [
    { el: "set-wait-response",  key: "waitResponse"          },
    { el: "set-background",     key: "enableBackgroundMode"  },
    { el: "set-notifications",  key: "showNotification"      },
    { el: "set-scroll",         key: "autoScroll"            },
    { el: "set-retry",          key: "retryFailed"           },
    { el: "set-clear-complete", key: "clearOnComplete"       },
    { el: "set-theme-contrast", key: "lightTheme"            }
  ];
  settingCheckboxes.forEach(({ el, key }) => {
    document.getElementById(el).addEventListener("change", (e) => {
      updateSettingField(key, e.target.checked);
    });
  });

  document.getElementById("set-default-delay").addEventListener("change", (e) => {
    const val = parseInt(e.target.value);
    if (!isNaN(val) && val > 0) updateSettingField("defaultDelay", val);
  });

  // FIX: Debounce storage change listener to prevent excessive re-renders.
  // The background updates storage frequently (e.g. nextPromptTime every second),
  // causing a full re-render on every tick without debouncing.
  let syncDebounceTimer = null;
  chrome.storage.onChanged.addListener(() => {
    clearTimeout(syncDebounceTimer);
    syncDebounceTimer = setTimeout(syncFullUI, 150);
  });
}

function triggerBackground(action) {
  chrome.runtime.sendMessage({ action }, () => {
    if (chrome.runtime.lastError) {
      console.warn("[Qprompter Popup] Message error:", chrome.runtime.lastError.message);
    }
    syncFullUI();
  });
}

// ── Prompt composers ──────────────────────────────────────────────────────
async function appendNewPrompt() {
  const textInput = document.getElementById("inp-new-prompt");
  const delayVal  = parseInt(document.getElementById("inp-delay-val").value);
  const delayUnit = document.getElementById("inp-delay-unit").value;
  const imageMode = document.getElementById("inp-image-mode").checked;

  if (!textInput.value.trim()) return;

  const newItem = {
    id:        Date.now().toString() + Math.random().toString(36).substr(2, 5),
    text:      textInput.value.trim(),
    delay:     isNaN(delayVal) || delayVal < 1 ? 10 : delayVal,
    delayUnit,
    imageMode,
    status:    "pending"
  };

  activeQueue.push(newItem);
  await chrome.storage.local.set({ queue: activeQueue });
  textInput.value = "";
  document.getElementById("inp-image-mode").checked = false;
  syncFullUI();
}

async function appendImagePrompt() {
  const textInput = document.getElementById("inp-img-text");
  if (!textInput.value.trim()) return;

  const newItem = {
    id:        Date.now().toString() + Math.random().toString(36).substr(2, 5),
    text:      textInput.value.trim(),
    delay:     activeSettings.defaultDelay    || 10,
    delayUnit: activeSettings.defaultDelayUnit || "seconds",
    imageMode: true,
    status:    "pending"
  };

  activeQueue.push(newItem);
  await chrome.storage.local.set({ queue: activeQueue });
  textInput.value = "";
  document.querySelector('.tab-trigger[data-tab="queue"]').click();
  syncFullUI();
}

async function generateVariablePrompts() {
  const template    = document.getElementById("inp-var-template").value.trim();
  const valuesText  = document.getElementById("inp-var-values").value.trim();

  if (!template || !valuesText) return;

  const values = valuesText.split(/[\n,]+/).map(v => v.trim()).filter(Boolean);
  if (values.length === 0) return;

  const generated = values.map(val => ({
    id:        Date.now().toString() + Math.random().toString(36).substr(2, 5),
    text:      template.replace("{value}", val),
    delay:     activeSettings.defaultDelay    || 10,
    delayUnit: activeSettings.defaultDelayUnit || "seconds",
    imageMode: false,
    status:    "pending"
  }));

  activeQueue = [...activeQueue, ...generated];
  await chrome.storage.local.set({ queue: activeQueue });
  document.getElementById("inp-var-values").value = "";
  document.querySelector('.tab-trigger[data-tab="queue"]').click();
  syncFullUI();
}

async function processTXTImportFile(e) {
  const file = e.target.files[0];
  if (!file) return;
  // Reset the input so the same file can be re-imported if needed
  e.target.value = "";

  const reader = new FileReader();
  reader.onload = async (event) => {
    const lines = event.target.result.split('\n').map(l => l.trim()).filter(Boolean);
    if (lines.length === 0) return;

    const imported = lines.map(line => ({
      id:        Date.now().toString() + Math.random().toString(36).substr(2, 5),
      text:      line,
      delay:     activeSettings.defaultDelay    || 10,
      delayUnit: activeSettings.defaultDelayUnit || "seconds",
      imageMode: false,
      status:    "pending"
    }));

    activeQueue = [...activeQueue, ...imported];
    await chrome.storage.local.set({ queue: activeQueue });
    syncFullUI();
  };
  reader.onerror = () => console.error("[Qprompter] File read error.");
  reader.readAsText(file);
}

// ── Queue controls ─────────────────────────────────────────────────────────
async function clearQueue() {
  activeQueue = [];
  await chrome.storage.local.set({ queue: [] });
  syncFullUI();
}

async function deleteQueueItem(id) {
  activeQueue = activeQueue.filter(item => item.id !== id);
  await chrome.storage.local.set({ queue: activeQueue });
  syncFullUI();
}

async function moveQueueItemInExtension(id, direction) {
  const index = activeQueue.findIndex(item => item.id === id);
  if (index === -1) return;
  const target = direction === 'up' ? index - 1 : index + 1;
  if (target < 0 || target >= activeQueue.length) return;

  const reordered = [...activeQueue];
  [reordered[index], reordered[target]] = [reordered[target], reordered[index]];
  activeQueue = reordered;
  await chrome.storage.local.set({ queue: activeQueue });
  syncFullUI();
}

async function requeueItemFromHistory(text, imageMode) {
  const newItem = {
    id:        Date.now().toString() + Math.random().toString(36).substr(2, 5),
    text,
    delay:     activeSettings.defaultDelay    || 10,
    delayUnit: activeSettings.defaultDelayUnit || "seconds",
    imageMode: imageMode || false,
    status:    "pending"
  };

  activeQueue.push(newItem);
  await chrome.storage.local.set({ queue: activeQueue });
  document.querySelector('.tab-trigger[data-tab="queue"]').click();
  syncFullUI();
}

async function clearHistoryLogs() {
  activeHistory = [];
  await chrome.storage.local.set({ history: [] });
  syncFullUI();
}

// ── Webhook simulator ─────────────────────────────────────────────────────
async function executeWebhookTrigger() {
  const template   = document.getElementById("inp-webhook-template").value.trim();
  const presetType = document.getElementById("inp-webhook-preset").value;

  let service   = "GitHub Actions Pipeline";
  let ref       = "release-v1.2";
  let message   = "Lint compilation aborted unexpectedly in server build task";
  let errorCode = "src/App.tsx(467,7): error TS2304: Cannot find name 'setSimChatState'.";

  if (presetType === "sentry") {
    service   = "Sentry Error Monitor";
    ref       = "api-production-us";
    message   = "Unhandled NullPointerException triggering order checkout";
    errorCode = "java.lang.NullPointerException: Cannot invoke 'stripeJS.Charge.create()' because client key is null.";
  } else if (presetType === "stripe") {
    service   = "Stripe Gateway Webhook";
    ref       = "dispute-status-web";
    message   = "Charge dispute_1N89v2K9c registered as active";
    errorCode = "gateway_code: charge_disputed. Reason: product_not_received. Disputed: $249.00 USD.";
  }

  const text = template
    .replace("{service}",    service)
    .replace("{ref}",        ref)
    .replace("{message}",    message)
    .replace("{error_code}", errorCode);

  const newItem = {
    id:        Date.now().toString() + Math.random().toString(36).substr(2, 5),
    text,
    delay:     5,
    delayUnit: "seconds",
    imageMode: false,
    status:    "pending"
  };

  activeQueue.unshift(newItem);
  await chrome.storage.local.set({ queue: activeQueue });

  chrome.runtime.sendMessage({ action: "START_QUEUE" }, () => syncFullUI());
  document.querySelector('.tab-trigger[data-tab="queue"]').click();
}

// ── Settings ──────────────────────────────────────────────────────────────
async function updateSettingField(key, value) {
  activeSettings[key] = value;
  await chrome.storage.local.set({ settings: activeSettings });
}

// ══════════════════════════════════════════════════════════════════════════
// Render engines
// ══════════════════════════════════════════════════════════════════════════

function renderQueueList() {
  const container = document.getElementById("queue-scrollbox");
  const emptyNode = document.getElementById("queue-empty-node");

  container.querySelectorAll(".prompt-item-card").forEach(el => el.remove());

  if (activeQueue.length === 0) {
    emptyNode.style.display = "flex";
    return;
  }

  emptyNode.style.display = "none";

  activeQueue.forEach((item, idx) => {
    const card = document.createElement("div");
    card.className = `prompt-item-card ${item.status}`;

    const stateLabel = item.status === 'running' ? 'sending...' : item.status;

    card.innerHTML = `
      <div class="prompt-item-row1">
        ${item.status === 'pending' ? `
          <div class="drag-handle" title="Drag to reorder">
            <svg viewBox="0 0 24 24" width="8" height="14" fill="currentColor" style="display:block;">
              <circle cx="8" cy="6" r="1.5"></circle>
              <circle cx="8" cy="12" r="1.5"></circle>
              <circle cx="8" cy="18" r="1.5"></circle>
              <circle cx="16" cy="6" r="1.5"></circle>
              <circle cx="16" cy="12" r="1.5"></circle>
              <circle cx="16" cy="18" r="1.5"></circle>
            </svg>
          </div>
        ` : ''}
        <div class="prompt-item-text">${escapeHtml(item.text)}</div>
        <div class="seq-controls-row">
          ${item.status === 'pending' ? `
            <button class="btn-seq btn-move-up"   data-id="${item.id}" ${idx === 0 ? 'disabled' : ''} title="Move up">
              <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="3" fill="none"><path d="M18 15l-6-6-6 6"></path></svg>
            </button>
            <button class="btn-seq btn-move-down" data-id="${item.id}" ${idx === activeQueue.length - 1 ? 'disabled' : ''} title="Move down">
              <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="3" fill="none"><path d="M6 9l6 6 6-6"></path></svg>
            </button>
          ` : ''}
          <button class="btn-trash" data-id="${item.id}" title="Remove">
            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2.5" fill="none">
              <polyline points="3 6 5 6 21 6"></polyline>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
            </svg>
          </button>
        </div>
      </div>
      <div class="prompt-item-meta">
        <div class="item-badges">
          <span class="item-badg">${item.delay} ${item.delayUnit === 'minutes' ? 'min' : 'sec'}</span>
          ${item.imageMode ? '<span class="item-badg img-badge">IMAGE</span>' : ''}
        </div>
        <span class="item-status-txt ${item.status}">${stateLabel}</span>
      </div>
    `;

    // Trash button
    card.querySelector(".btn-trash").addEventListener("click", (e) => {
      e.stopPropagation();
      deleteQueueItem(item.id);
    });

    // Drag-and-drop + up/down buttons (pending items only)
    if (item.status === 'pending') {
      card.setAttribute('draggable', 'true');

      card.addEventListener("dragstart", (e) => {
        card.classList.add("dragging");
        e.dataTransfer.effectAllowed = "move";
        e.dataTransfer.setData("text/plain", String(idx));
      });
      card.addEventListener("dragend", () => {
        card.classList.remove("dragging");
        container.querySelectorAll(".prompt-item-card").forEach(c => c.classList.remove("drag-over"));
      });
      card.addEventListener("dragover", (e) => {
        e.preventDefault();
        card.classList.add("drag-over");
      });
      card.addEventListener("dragleave", () => card.classList.remove("drag-over"));
      card.addEventListener("drop", async (e) => {
        e.preventDefault();
        card.classList.remove("drag-over");
        const fromIdx = parseInt(e.dataTransfer.getData("text/plain"), 10);
        if (!isNaN(fromIdx) && fromIdx !== idx && fromIdx >= 0 && fromIdx < activeQueue.length) {
          const reordered = [...activeQueue];
          const [dragged] = reordered.splice(fromIdx, 1);
          reordered.splice(idx, 0, dragged);
          activeQueue = reordered;
          await chrome.storage.local.set({ queue: activeQueue });
          syncFullUI();
        }
      });

      const upBtn = card.querySelector(".btn-move-up");
      if (upBtn) upBtn.addEventListener("click", (e) => { e.stopPropagation(); moveQueueItemInExtension(item.id, 'up'); });

      const downBtn = card.querySelector(".btn-move-down");
      if (downBtn) downBtn.addEventListener("click", (e) => { e.stopPropagation(); moveQueueItemInExtension(item.id, 'down'); });
    }

    container.appendChild(card);
  });
}

function renderLibraryList() {
  const container = document.getElementById("library-scrollbox");
  container.innerHTML = "";

  if (activeLibrary.length === 0) {
    container.innerHTML = `<p style="text-align:center; color:var(--text-muted); font-size:11px; margin-top:20px;">No templates found.</p>`;
    return;
  }

  activeLibrary.forEach((lib) => {
    const card = document.createElement("div");
    card.className = "lib-card shadow-sm";
    card.innerHTML = `
      <div class="lib-card-top">
        <h3>${escapeHtml(lib.title)}</h3>
        <span class="lib-cat-label">${escapeHtml(lib.category)}</span>
      </div>
      <p>${escapeHtml(lib.text.substring(0, 80))}${lib.text.length > 80 ? '...' : ''}</p>
    `;
    card.addEventListener("click", () => requeueItemFromHistory(lib.text, false));
    container.appendChild(card);
  });
}

function renderHistoryList() {
  const container = document.getElementById("history-scrollbox");
  const emptyNode = document.getElementById("history-empty-node");

  container.querySelectorAll(".prompt-item-card").forEach(el => el.remove());

  if (activeHistory.length === 0) {
    emptyNode.style.display = "flex";
    return;
  }

  emptyNode.style.display = "none";

  activeHistory.forEach((h) => {
    const card = document.createElement("div");
    card.className = "prompt-item-card sent no-border";

    const time = new Date(h.timestamp).toLocaleTimeString([], {
      hour:   '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });

    card.innerHTML = `
      <div class="prompt-item-row1">
        <div class="history-item-desc">
          <strong>[${time}]</strong> ${escapeHtml(h.text)}
        </div>
        <button class="btn-requeue" title="Add back to queue">RE-Q</button>
      </div>
      <div class="prompt-item-meta" style="margin-top:2px; border:none; padding-top:0;">
        <span class="text-muted" style="font-size:8px;">Gap: ${h.delay}s | Status: ${escapeHtml(h.status)}</span>
      </div>
    `;

    card.querySelector(".btn-requeue").addEventListener("click", () => {
      requeueItemFromHistory(h.text, h.imageMode);
    });

    container.appendChild(card);
  });
}

// ── Status & footer ───────────────────────────────────────────────────────
function updateStatusDisplay() {
  const badge = document.getElementById("status-display");
  badge.className = "status-indicator " + activeStatus.toLowerCase();

  const isRunning = activeStatus === "RUNNING";
  const isPaused  = activeStatus === "PAUSED";

  // FIX: START button label dynamically changes to RESUME when paused
  const startBtn = document.getElementById("btn-start");
  startBtn.disabled = isRunning;
  if (isPaused) {
    startBtn.innerHTML = startBtn.innerHTML.replace(/START|RESUME/, 'RESUME');
    badge.innerText = "PAUSED";
  } else {
    startBtn.innerHTML = startBtn.innerHTML.replace(/START|RESUME/, 'START');
    badge.innerText = activeStatus;
  }

  document.getElementById("btn-pause").disabled = !isRunning;
  document.getElementById("btn-stop").disabled  = !isRunning && !isPaused;
}

function updateFooterStats() {
  const pendingCount = activeQueue.filter(p => p.status === "pending").length;
  const banner = document.getElementById("task-completion-banner");
  // FIX: Use textContent to avoid potential XSS; update both spans cleanly
  banner.innerHTML = `Queue Total: ${activeQueue.length} &bull; ${pendingCount} Pending`;
  document.getElementById("queue-header-txt").innerText = `Queue (${pendingCount} Remaining)`;
}

function loadSettingsInputs() {
  document.getElementById("set-default-delay").value    = activeSettings.defaultDelay    ?? 10;
  document.getElementById("set-wait-response").checked  = activeSettings.waitResponse     !== false;
  document.getElementById("set-background").checked     = activeSettings.enableBackgroundMode !== false;
  document.getElementById("set-notifications").checked  = activeSettings.showNotification  !== false;
  document.getElementById("set-scroll").checked         = activeSettings.autoScroll        !== false;
  document.getElementById("set-retry").checked          = activeSettings.retryFailed       === true;
  document.getElementById("set-clear-complete").checked = activeSettings.clearOnComplete   === true;
  document.getElementById("set-theme-contrast").checked = activeSettings.lightTheme        === true;
}

// ── Timer display ─────────────────────────────────────────────────────────
function syncTimerUI() {
  const timer = document.getElementById("countdown-timer");
  if (activeStatus !== "RUNNING") {
    timer.style.display = "none";
    return;
  }

  chrome.storage.local.get(["nextPromptTime"], (data) => {
    if (!data.nextPromptTime) {
      timer.style.display = "none";
      return;
    }
    const diff = Math.max(0, Math.round((data.nextPromptTime - Date.now()) / 1000));
    if (diff > 0) {
      timer.style.display = "inline-block";
      timer.innerText = `Next: ${diff}s`;
    } else {
      timer.style.display = "none";
    }
  });
}

// ── Library search ────────────────────────────────────────────────────────
function searchLibraryTemplates() {
  const query = document.getElementById("inp-search-lib").value.toLowerCase();

  chrome.storage.local.get(["library"], (data) => {
    const lib = data.library || [];
    activeLibrary = query
      ? lib.filter(item =>
          item.title.toLowerCase().includes(query) ||
          item.text.toLowerCase().includes(query)  ||
          item.category.toLowerCase().includes(query)
        )
      : lib;
    renderLibraryList();
  });
}

// ── Utilities ─────────────────────────────────────────────────────────────
function escapeHtml(str) {
  if (!str) return "";
  return str
    .replace(/&/g,  "&amp;")
    .replace(/</g,  "&lt;")
    .replace(/>/g,  "&gt;")
    .replace(/"/g,  "&quot;")
    .replace(/'/g,  "&#039;");
}
