/**
 * Qprompter - Background Service Worker (Manifest V3)
 * Manages the queue state, timings, and coordinates prompt injections.
 */

// Concurrency lock — prevents processNextPrompt from running simultaneously
let isProcessing = false;

// ── Storage bootstrap ──────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["queue", "history", "library", "settings", "status"], (result) => {
    const updates = {};
    if (!result.queue)    updates.queue   = [];
    if (!result.history)  updates.history = [];
    if (!result.library)  updates.library = getInitialLibrary();
    if (!result.status)   updates.status  = "IDLE";
    if (!result.settings) {
      updates.settings = {
        defaultDelay:        10,
        defaultDelayUnit:    "seconds",
        defaultRepeat:       1,
        waitResponse:        true,
        enableBackgroundMode:true,
        showTimer:           true,
        autoScroll:          true,
        persistQueue:        true,
        retryFailed:         false,
        pauseNoTab:          true,
        autoDetectTab:       true,
        preferActive:        true,
        showNotification:    true,
        clearOnComplete:     false,
        lightTheme:          false
      };
    }
    chrome.storage.local.set(updates);
  });
});

// ── Alarm handler ─────────────────────────────────────────────────────────
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "qprompter_next_prompt") {
    console.log("[Qprompter] Alarm fired — processing next prompt.");
    await processNextPrompt();
  }
});

// ── Message hub ───────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.action) {
    case "START_QUEUE":
      startAutomation().then(() => sendResponse({ status: "started" }));
      break;
    case "PAUSE_QUEUE":
      pauseAutomation().then(() => sendResponse({ status: "paused" }));
      break;
    case "STOP_QUEUE":
      stopAutomation().then(() => sendResponse({ status: "stopped" }));
      break;
    case "RESUME_QUEUE":
      resumeAutomation().then(() => sendResponse({ status: "resumed" }));
      break;
    case "NOTIFY_GENERATION_COMPLETE":
      handleGenerationComplete(sender.tab ? sender.tab.id : null)
        .then(() => sendResponse({ status: "acknowledged" }));
      break;
    case "CONTENT_SCRIPT_ERROR":
      handlePromptFailed(message.error)
        .then(() => sendResponse({ status: "notified" }));
      break;
    case "TRIGGER_WEBHOOK_EVENT":
      console.log("[Qprompter BG] External webhook received:", message.payload);
      sendResponse({ status: "processed" });
      break;
    default:
      sendResponse({ status: "unknown_action" });
  }
  return true; // Keep the message channel open for async responses
});

// ── Automation controls ────────────────────────────────────────────────────
async function startAutomation() {
  // Reset any stuck "running" items back to pending before starting fresh
  const data = await chrome.storage.local.get(["queue"]);
  const queue = (data.queue || []).map(item =>
    item.status === "running" ? { ...item, status: "pending" } : item
  );
  await chrome.storage.local.set({ status: "RUNNING", queue });
  updateBadge();
  console.log("[Qprompter] Automation started. First prompt executes immediately.");
  await processNextPrompt();
}

async function pauseAutomation() {
  // FIX: Reset any currently "running" item back to "pending" so it gets retried on resume
  const data = await chrome.storage.local.get(["queue"]);
  const queue = (data.queue || []).map(item =>
    item.status === "running" ? { ...item, status: "pending" } : item
  );
  await chrome.storage.local.set({ status: "PAUSED", queue });
  chrome.alarms.clear("qprompter_next_prompt");
  isProcessing = false; // Release lock on pause
  updateBadge();
  console.log("[Qprompter] Automation paused.");
}

async function stopAutomation() {
  // FIX: Reset any "running" item back to "pending" on stop so queue is restartable
  const data = await chrome.storage.local.get(["queue"]);
  const queue = (data.queue || []).map(item =>
    item.status === "running" ? { ...item, status: "pending" } : item
  );
  await chrome.storage.local.set({ status: "IDLE", queue, nextPromptTime: null });
  chrome.alarms.clear("qprompter_next_prompt");
  isProcessing = false; // Release lock on stop
  updateBadge();
  console.log("[Qprompter] Automation stopped.");
}

async function resumeAutomation() {
  await chrome.storage.local.set({ status: "RUNNING" });
  updateBadge();
  console.log("[Qprompter] Automation resumed. Continuing from next pending item.");
  await processNextPrompt();
}

// ── Generation / Failure handlers ─────────────────────────────────────────
async function handleGenerationComplete(tabId) {
  const data = await chrome.storage.local.get(["status", "queue", "settings"]);
  if (data.status !== "RUNNING") return;

  const activeIndex = data.queue.findIndex(item => item.status === "running");
  if (activeIndex === -1) return; // Already handled or paused

  const currentPrompt = data.queue[activeIndex];
  data.queue[activeIndex] = { ...currentPrompt, status: "sent" };

  await addToHistory(currentPrompt, "Success");
  await chrome.storage.local.set({ queue: data.queue });
  updateBadge();

  scheduleNext(currentPrompt, data.settings);
}

async function handlePromptFailed(error) {
  const data = await chrome.storage.local.get(["status", "queue", "settings"]);
  if (!data.queue) return;

  const activeIndex = data.queue.findIndex(item => item.status === "running");
  if (activeIndex === -1) return;

  const currentPrompt = data.queue[activeIndex];
  data.queue[activeIndex] = { ...currentPrompt, status: "failed", error };

  await addToHistory(currentPrompt, "Failed: " + error);
  await chrome.storage.local.set({ queue: data.queue });
  updateBadge();

  if (data.settings && data.settings.retryFailed) {
    console.log("[Qprompter] Prompt failed, marking and skipping:", error);
  }

  // Schedule next prompt even after failure
  if (data.settings) {
    scheduleNext(currentPrompt, data.settings);
  }
}

// ── Scheduling ─────────────────────────────────────────────────────────────
function scheduleNext(currentPrompt, settings) {
  // FIX: Use explicit null/undefined check instead of `||` so delay of 0 doesn't fall through incorrectly
  const rawDelay = (currentPrompt.delay != null) ? currentPrompt.delay : (settings.defaultDelay || 10);
  const delaySec = (currentPrompt.delayUnit === "minutes") ? rawDelay * 60 : rawDelay;

  // FIX: Enforce minimum of 1 second to avoid 0-second alarms (Chrome floors to 1 min in packed extensions)
  const safeDelaySec = Math.max(1, delaySec);

  console.log(`[Qprompter] Scheduling next prompt in ${safeDelaySec}s`);

  chrome.alarms.clear("qprompter_next_prompt", () => {
    chrome.alarms.create("qprompter_next_prompt", {
      delayInMinutes: safeDelaySec / 60
    });
  });

  const expectedRunTime = Date.now() + (safeDelaySec * 1000);
  chrome.storage.local.set({ nextPromptTime: expectedRunTime });
}

// ── Core prompt processor ──────────────────────────────────────────────────
async function processNextPrompt() {
  // FIX: Concurrency lock — prevents race condition from simultaneous alarm + manual trigger
  if (isProcessing) {
    console.log("[Qprompter] processNextPrompt skipped — already processing.");
    return;
  }
  isProcessing = true;

  try {
    const data = await chrome.storage.local.get(["status", "queue", "settings"]);
    if (data.status !== "RUNNING") {
      console.log("[Qprompter] Not running, aborting processNextPrompt.");
      return;
    }

    const queue = data.queue || [];
    const nextIndex = queue.findIndex(item => item.status === "pending");

    if (nextIndex === -1) {
      await completeQueue(data.settings);
      return;
    }

    const promptItem = queue[nextIndex];
    const targetTab = await findSupportedAITab(data.settings);

    if (!targetTab) {
      if (data.settings.pauseNoTab) {
        await chrome.storage.local.set({ status: "PAUSED" });
        updateBadge();
        showSystemNotification(
          "Qprompter Paused",
          "No supported AI chat tab found. Open ChatGPT, Claude, Gemini, etc. and resume."
        );
      } else {
        // Retry in 5 seconds
        chrome.alarms.create("qprompter_next_prompt", { delayInMinutes: 5 / 60 });
      }
      return;
    }

    targetTabId = targetTab.id;
    activeRequestsCount = 0;
    await chrome.storage.local.set({
      currentTabId: targetTab.id,
      isNetworkStreaming: false
    });

    // Set up offscreen watchdog if waitResponse is enabled
    if (data.settings.waitResponse) {
      try {
        await setupOffscreenDocument();
        chrome.runtime.sendMessage({
          type: "START_OFFSCREEN_MONITOR",
          tabId: targetTab.id
        }).catch(() => {});
      } catch (err) {
        console.warn("[Qprompter BG] Offscreen setup warning:", err.message);
      }
    }

    // Mark as running
    queue[nextIndex] = { ...promptItem, status: "running" };
    await chrome.storage.local.set({ queue, nextPromptTime: null });
    updateBadge();

    // FIX: Use async/await for executeScript + message passing (MV3 best practice)
    try {
      // Inject content script — catch errors from re-injection (already injected)
      try {
        await chrome.scripting.executeScript({
          target: { tabId: targetTab.id },
          files: ["content.js"]
        });
      } catch (injErr) {
        // Injection errors are expected when content script is already loaded; safe to ignore
        console.log("[Qprompter] Content script already present or injection note:", injErr.message);
      }

      // Brief pause to ensure content script is initialised and listening
      await new Promise(resolve => setTimeout(resolve, 150));

      // FIX: Promisify sendMessage for proper error handling
      const response = await new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(
          targetTab.id,
          {
            action: "SEND_PROMPT_PAYLOAD",
            text: promptItem.text,
            waitResponse: data.settings.waitResponse,
            imageMode: promptItem.imageMode,
            autoScroll: data.settings.autoScroll
          },
          (res) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              resolve(res);
            }
          }
        );
      });

      if (!response || !response.success) {
        await handlePromptFailed(response ? response.error : "Unknown content injection error");
      } else {
        console.log("[Qprompter] Prompt typed and submitted successfully.");
        // If not waiting for AI response, mark as sent and schedule next immediately
        if (!data.settings.waitResponse) {
          queue[nextIndex] = { ...queue[nextIndex], status: "sent" };
          await chrome.storage.local.set({ queue });
          await addToHistory(promptItem, "Success");
          scheduleNext(promptItem, data.settings);
        }
        // If waitResponse=true, the content script will send NOTIFY_GENERATION_COMPLETE
      }
    } catch (err) {
      console.error("[Qprompter] Prompt execution error:", err.message);
      await handlePromptFailed("Automation error: " + err.message);
    }
  } finally {
    // FIX: Always release the lock, even on error
    isProcessing = false;
  }
}

// ── Tab finder ────────────────────────────────────────────────────────────
async function findSupportedAITab(settings) {
  const tabs = await chrome.tabs.query({});
  const patterns = [
    "chatgpt.com", "chat.openai.com", "claude.ai",
    "gemini.google.com", "bard.google.com",
    "copilot.microsoft.com", "bing.com", "poe.com", "character.ai"
  ];

  const matchedTabs = tabs.filter(t => t.url && patterns.some(p => t.url.includes(p)));
  if (matchedTabs.length === 0) return null;

  if (settings && settings.preferActive) {
    const activeTab = matchedTabs.find(t => t.active);
    if (activeTab) return activeTab;
  }

  return matchedTabs[0];
}

// ── History ───────────────────────────────────────────────────────────────
async function addToHistory(promptItem, statusLabel) {
  const data = await chrome.storage.local.get(["history"]);
  const history = data.history || [];

  const record = {
    id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
    text: promptItem.text,
    timestamp: new Date().toISOString(),
    status: statusLabel.includes("Success") ? "sent" : "failed",
    error: promptItem.error || "",
    delay: promptItem.delay,
    delayUnit: promptItem.delayUnit,
    imageMode: promptItem.imageMode || false
  };

  history.unshift(record);
  await chrome.storage.local.set({ history: history.slice(0, 50) });
}

// ── Queue completion ──────────────────────────────────────────────────────
async function completeQueue(settings) {
  await chrome.storage.local.set({ status: "COMPLETE", nextPromptTime: null });
  updateBadge();
  console.log("[Qprompter] All prompts complete.");

  if (settings && settings.showNotification) {
    showSystemNotification("Qprompter Queue Finished!", "All prompts have been processed.");
  }
  if (settings && settings.clearOnComplete) {
    await chrome.storage.local.set({ queue: [] });
  }
}

// ── Badge updater ─────────────────────────────────────────────────────────
async function updateBadge() {
  const data = await chrome.storage.local.get(["queue", "status"]);
  const status = data.status || "IDLE";
  const queue  = data.queue  || [];

  if (status === "RUNNING") {
    const pending = queue.filter(p => p.status === "pending").length;
    chrome.action.setBadgeText({ text: pending.toString() });
    chrome.action.setBadgeBackgroundColor({ color: "#0ea5e9" });
  } else if (status === "PAUSED") {
    chrome.action.setBadgeText({ text: "II" });
    chrome.action.setBadgeBackgroundColor({ color: "#eab308" });
  } else if (status === "COMPLETE") {
    chrome.action.setBadgeText({ text: "✔" });
    chrome.action.setBadgeBackgroundColor({ color: "#22c55e" });
  } else {
    chrome.action.setBadgeText({ text: "" });
  }
}

// ── Notifications ─────────────────────────────────────────────────────────
function showSystemNotification(title, message) {
  chrome.notifications.create({
    type: "basic",
    iconUrl: "icons/icon128.png",
    title,
    message,
    priority: 2
  });
}

// ── Initial library ───────────────────────────────────────────────────────
function getInitialLibrary() {
  return [
    {
      id: "lib1",
      title: "Blog Post Outline",
      text: "Create a detailed blog post outline about {topic} with sub-headings, key takeaways, and SEO keyword targets.",
      category: "Marketing"
    },
    {
      id: "lib2",
      title: "Rust Bug Analyzer",
      text: "Look at the following Rust code and point out memory issues, lifespans, and performance bottlenecks: \n\n{code}",
      category: "Coding"
    },
    {
      id: "lib3",
      title: "Instagram Carousel Planner",
      text: "Draft a 5-slider Instagram carousel layout outlining text and visual cues for: {concept}",
      category: "Social Media"
    },
    {
      id: "lib4",
      title: "Dynamic Email Pitch",
      text: "Write a short, engaging cold B2B outreach email pitching our product {solution} targeting the pain-point: {pain_point}",
      category: "Business"
    }
  ];
}

// ══════════════════════════════════════════════════════════════════════════
// Offscreen Document Management
// ══════════════════════════════════════════════════════════════════════════

let targetTabId       = null;
let activeRequestsCount = 0;
let creatingOffscreen = null;

// Restore targetTabId from storage on service worker wake
chrome.storage.local.get(["currentTabId"], (items) => {
  if (items.currentTabId) targetTabId = items.currentTabId;
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.currentTabId) {
    targetTabId = changes.currentTabId.newValue;
  }
});

async function setupOffscreenDocument() {
  if (await hasOffscreenDocument()) return;

  if (creatingOffscreen) {
    await creatingOffscreen;
    return;
  }

  creatingOffscreen = chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["DOM_SCRAPING"],
    justification: "Streaming watchdog and network state coordination."
  });
  await creatingOffscreen;
  creatingOffscreen = null;
}

async function hasOffscreenDocument() {
  if (chrome.runtime.getContexts) {
    const contexts = await chrome.runtime.getContexts({
      contextTypes: ["OFFSCREEN_DOCUMENT"]
    });
    return contexts.length > 0;
  }
  // Fallback for older Chrome versions
  try {
    const clients = await self.clients.matchAll();
    return clients.some(c => c.url.endsWith("offscreen.html"));
  } catch (_) {
    return false;
  }
}

// ══════════════════════════════════════════════════════════════════════════
// WebRequest Interceptors — stream state tracking
// ══════════════════════════════════════════════════════════════════════════

const STREAM_URL_PATTERNS = [
  "conversation", "completion", "stream",
  "batchexecute", "backend-api", "v1/chat", "trpc"
];

function isStreamUrl(url) {
  const lower = url.toLowerCase();
  return STREAM_URL_PATTERNS.some(p => lower.includes(p));
}

if (chrome.webRequest) {
  chrome.webRequest.onBeforeRequest.addListener(
    (details) => {
      if (targetTabId && details.tabId === targetTabId && isStreamUrl(details.url)) {
        activeRequestsCount++;
        console.log("[Qprompter WebRequest] Stream started. Count:", activeRequestsCount);
        chrome.storage.local.set({ isNetworkStreaming: true });
        chrome.tabs.sendMessage(targetTabId, {
          action: "UPDATE_NETWORK_STREAM_STATUS",
          isNetworkStreaming: true
        }).catch(() => {});
      }
    },
    { urls: ["<all_urls>"] }
  );

  const handleStreamFinish = (details) => {
    if (targetTabId && details.tabId === targetTabId && isStreamUrl(details.url)) {
      if (activeRequestsCount > 0) activeRequestsCount--;
      const isStreaming = activeRequestsCount > 0;
      console.log("[Qprompter WebRequest] Stream ended. Remaining:", activeRequestsCount);
      chrome.storage.local.set({ isNetworkStreaming: isStreaming });
      chrome.tabs.sendMessage(targetTabId, {
        action: "UPDATE_NETWORK_STREAM_STATUS",
        isNetworkStreaming: isStreaming
      }).catch(() => {});
    }
  };

  chrome.webRequest.onCompleted.addListener(handleStreamFinish, { urls: ["<all_urls>"] });
  chrome.webRequest.onErrorOccurred.addListener(handleStreamFinish, { urls: ["<all_urls>"] });
}
