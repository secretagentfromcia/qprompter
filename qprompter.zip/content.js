/**
 * Qprompter - Content Script
 * Responsible for DOM analysis, writing the text, clicking submit,
 * and reporting when the AI platform finishes generating a response.
 */

// ── Guard: prevent duplicate injection ────────────────────────────────────
if (typeof qprompterInjected === 'undefined') {
  var qprompterInjected = true;
  console.log("[Qprompter] Content script loaded.");

  // ── Network stream state ────────────────────────────────────────────────
  var localIsNetworkStreaming = false;

  chrome.storage.local.get(["isNetworkStreaming"], (items) => {
    if (items && typeof items.isNetworkStreaming !== 'undefined') {
      localIsNetworkStreaming = !!items.isNetworkStreaming;
    }
  });

  chrome.storage.onChanged.addListener((changes) => {
    if (changes.isNetworkStreaming) {
      localIsNetworkStreaming = !!changes.isNetworkStreaming.newValue;
    }
  });

  // ── Observer guard: only one active observer at a time ─────────────────
  var qprompterObserverActive = false;

  // ── Message listener ────────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "SEND_PROMPT_PAYLOAD") {
      executePromptSubmission(message)
        .then(() => sendResponse({ success: true }))
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true; // async
    }
    if (message.action === "UPDATE_NETWORK_STREAM_STATUS") {
      localIsNetworkStreaming = !!message.isNetworkStreaming;
    }
  });
}

// ══════════════════════════════════════════════════════════════════════════
// Core prompt submission
// ══════════════════════════════════════════════════════════════════════════

async function executePromptSubmission(payload) {
  console.log("[Qprompter] Sending prompt:", payload.text.substring(0, 60) + "...");

  if (payload.autoScroll) {
    window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
  }

  const host = window.location.hostname.toLowerCase();
  const selectors = getSelectorsForPlatform(host);

  // ── 1. Locate the input element ─────────────────────────────────────────
  let inputElement = null;
  for (const sel of selectors.inputs) {
    inputElement = document.querySelector(sel);
    if (inputElement) break;
  }

  if (!inputElement) {
    throw new Error("Could not find the prompt input on this AI platform.");
  }

  // ── 2. Set the prompt text using framework-compatible methods ───────────
  await setInputValue(inputElement, payload.text);

  // Wait for the virtual DOM to register the change (React/ProseMirror)
  await delay(400);

  // ── 3. Locate the send button ───────────────────────────────────────────
  let sendButton = null;
  for (const sel of selectors.buttons) {
    const el = document.querySelector(sel);
    if (el && !el.disabled) { sendButton = el; break; }
  }

  // Fallback: search all buttons for a send/submit label
  if (!sendButton) {
    const allButtons = Array.from(document.querySelectorAll('button, [role="button"]'));
    sendButton = allButtons.find(btn => {
      const label = (
        btn.getAttribute('aria-label') || btn.innerText || btn.title || ''
      ).toLowerCase();
      return (
        (label.includes('send') || label.includes('submit') || label.includes('generate')) &&
        !btn.disabled &&
        btn.offsetWidth > 0 && btn.offsetHeight > 0
      );
    });
  }

  if (!sendButton) {
    throw new Error("Input field loaded, but the Send button is disabled or not found.");
  }

  sendButton.click();
  console.log("[Qprompter] Send button clicked.");

  // ── 4. Optionally wait for AI to finish generating ──────────────────────
  if (payload.waitResponse) {
    startAIGeneratingObserver(selectors.stops, selectors.spinner);
  }

  return true;
}

// ══════════════════════════════════════════════════════════════════════════
// FIX: Framework-compatible input setter
// Setting .value directly or .innerHTML bypasses React/ProseMirror internal
// state — the send button stays disabled. We use the native property setter
// for textareas (React) and execCommand('insertText') for contenteditable
// (ProseMirror/Quill/Slate used by Claude.ai, ChatGPT, Gemini, etc.)
// ══════════════════════════════════════════════════════════════════════════

async function setInputValue(el, text) {
  el.focus();
  await delay(50);

  if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
    // React tracks input via a synthetic event on the native DOM descriptor.
    // Setting .value directly won't trigger React's onChange — use the native setter.
    const proto = el.tagName === 'TEXTAREA'
      ? window.HTMLTextAreaElement.prototype
      : window.HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');

    if (descriptor && descriptor.set) {
      descriptor.set.call(el, text);
    } else {
      el.value = text;
    }

    el.dispatchEvent(new Event('input',  { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));

  } else {
    // Contenteditable div (ProseMirror on Claude.ai, Quill on some others).
    // execCommand('insertText') is the only method that properly hooks into
    // these editors' internal event dispatching so the send button enables.
    el.focus();

    // Select all existing content first
    document.execCommand('selectAll', false, null);

    // Insert the new text — this triggers ProseMirror/Quill/Slate handlers
    const inserted = document.execCommand('insertText', false, text);

    if (!inserted) {
      // Fallback: direct DOM manipulation + InputEvent (for any future editors)
      el.textContent = '';
      const range = document.createRange();
      const sel   = window.getSelection();
      range.selectNodeContents(el);
      range.collapse(false);
      sel.removeAllRanges();
      sel.addRange(range);

      el.dispatchEvent(new InputEvent('input', {
        bubbles:     true,
        cancelable:  true,
        data:        text,
        inputType:   'insertText'
      }));
    }
  }
}

// ══════════════════════════════════════════════════════════════════════════
// AI response-complete detector (multi-signal)
// ══════════════════════════════════════════════════════════════════════════

function startAIGeneratingObserver(stopSelectors, spinnerSelectors) {
  // FIX: Guard against multiple overlapping observers
  if (qprompterObserverActive) {
    console.warn("[Qprompter Observer] Already active — skipping duplicate.");
    return;
  }
  qprompterObserverActive = true;

  let isGeneratingDetected  = false;
  let textStreamActive      = false;
  let lastTextLength        = document.body.innerText.length;
  let lastTextChangeTime    = Date.now();
  let domMutationCount      = 0;
  let lastMutationTime      = Date.now();
  let lastNetworkActiveTime = 0;
  let checkCount            = 0;
  const MAX_IDLE_CHECKS     = 20; // 20 × 300ms = 6 seconds max wait for response to start

  console.log("[Qprompter Observer] Starting response detector.");

  function cleanup() {
    clearInterval(pollInterval);
    observer.disconnect();
    qprompterObserverActive = false;
    console.log("[Qprompter Observer] Cleaned up.");
  }

  // ── MutationObserver: track meaningful text changes ─────────────────────
  const observer = new MutationObserver((mutations) => {
    const IGNORED_TAGS = new Set([
      'svg','path','circle','rect','g','button','style','script','img','iframe'
    ]);

    let textModified = false;

    for (const mutation of mutations) {
      if (mutation.type === 'characterData') {
        if ((mutation.target.textContent || '').trim().length > 0) {
          textModified = true;
          break;
        }
      } else if (mutation.type === 'childList') {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.TEXT_NODE) {
            if ((node.textContent || '').trim().length > 0) {
              textModified = true;
              break;
            }
          } else if (node.nodeType === Node.ELEMENT_NODE) {
            if (!IGNORED_TAGS.has(node.tagName.toLowerCase()) &&
                (node.textContent || '').trim().length > 0) {
              textModified = true;
              break;
            }
          }
        }
      }
      if (textModified) break;
    }

    if (textModified) {
      domMutationCount++;
      lastMutationTime = Date.now();
      if (domMutationCount > 3 && !textStreamActive) {
        console.log("[Qprompter Observer] Text stream mutations detected.");
        textStreamActive      = true;
        isGeneratingDetected  = true;
      }
    }
  });

  observer.observe(document.body, {
    childList:     true,
    subtree:       true,
    characterData: true
  });

  // ── Polling interval: cross-reference all signals ───────────────────────
  const pollInterval = setInterval(() => {
    // Signal 1: UI stop/loading indicators
    const hasStopBtn = stopSelectors.some(sel => {
      const el = document.querySelector(sel);
      return el && el.offsetWidth > 0 && el.offsetHeight > 0;
    });

    const hasSpinner = (spinnerSelectors || []).some(sel => {
      const el = document.querySelector(sel);
      return el && el.offsetWidth > 0 && el.offsetHeight > 0;
    });

    const hasFallbackLoader = Array.from(
      document.querySelectorAll('button, [role="button"]')
    ).some(btn => {
      const label = (btn.getAttribute('aria-label') || btn.innerText || btn.title || '').toLowerCase();
      return (label.includes('stop') || label.includes('cancel') || label.includes('pause')) &&
             btn.offsetWidth > 0 && btn.offsetHeight > 0;
    });

    const isUiGenerating = hasStopBtn || hasSpinner || hasFallbackLoader;

    // Signal 2: Text length changes
    const currentTextLength = (document.body.innerText || '').length;
    if (currentTextLength !== lastTextLength) {
      lastTextLength     = currentTextLength;
      lastTextChangeTime = Date.now();
      if (!textStreamActive && isGeneratingDetected) textStreamActive = true;
    }

    // Signal 3: Network streaming state — read from local variable (kept in sync by storage listener)
    if (localIsNetworkStreaming) {
      lastNetworkActiveTime = Date.now();
    }

    // FIX: Read storage asynchronously but don't block — use stored local variable as primary signal
    const timeSinceTextChange   = Date.now() - lastTextChangeTime;
    const timeSinceMutation     = Date.now() - lastMutationTime;
    const timeSinceNetworkActive = Date.now() - lastNetworkActiveTime;

    // Consider network "recently active" within 2.5 s grace (SSE/WebSocket jitter)
    const isNetworkRecentlyActive = localIsNetworkStreaming ||
      (lastNetworkActiveTime > 0 && timeSinceNetworkActive < 2500);

    const isGenerating =
      isUiGenerating ||
      (textStreamActive && timeSinceTextChange < 1500) ||
      isNetworkRecentlyActive;

    if (isGenerating) {
      if (!isGeneratingDetected) {
        console.log("[Qprompter Observer] AI generation detected.");
        isGeneratingDetected = true;
      }
      checkCount = 0; // Reset idle counter whenever we see activity
    } else {
      if (isGeneratingDetected) {
        // Was generating — check for stable state before declaring complete
        if (timeSinceMutation > 1500 && timeSinceTextChange > 1500 && !isNetworkRecentlyActive) {
          console.log("[Qprompter Observer] AI response stable — notifying background.");
          cleanup();
          chrome.runtime.sendMessage({ action: "NOTIFY_GENERATION_COMPLETE" });
        }
        // else: still stabilising, wait
      } else {
        // Initial wait: response hasn't started yet
        checkCount++;
        if (checkCount >= MAX_IDLE_CHECKS) {
          console.log("[Qprompter Observer] Timeout — no generation detected after 6s. Proceeding.");
          cleanup();
          chrome.runtime.sendMessage({ action: "NOTIFY_GENERATION_COMPLETE" });
        }
      }
    }
  }, 300);
}

// ══════════════════════════════════════════════════════════════════════════
// Platform selector maps
// ══════════════════════════════════════════════════════════════════════════

function getSelectorsForPlatform(host) {
  const result = { inputs: [], buttons: [], stops: [], spinner: [] };

  if (host.includes('chatgpt.com') || host.includes('openai.com')) {
    result.inputs  = ['#prompt-textarea', 'textarea', 'div[contenteditable="true"]'];
    result.buttons = ['[data-testid="send-button"]', 'button[aria-label*="Send"]', 'button[type="submit"]'];
    result.stops   = ['[data-testid="stop-button"]', 'button[aria-label*="Stop"]'];
    result.spinner = ['.loading', '.spinner'];

  } else if (host.includes('claude.ai')) {
    result.inputs  = ['div[contenteditable="true"]', 'textarea'];
    result.buttons = ['button[aria-label*="Send"]', 'button[type="submit"]', '[data-testid="send-button"]'];
    result.stops   = ['button[aria-label*="Stop"]', 'button[aria-label="Stop Generating"]'];
    result.spinner = ['.loading-indicator'];

  } else if (host.includes('gemini.google.com') || host.includes('bard.google.com')) {
    result.inputs  = ['rich-textarea div[contenteditable="true"]', 'textarea', 'div[contenteditable="true"]'];
    result.buttons = ['button.send-button', 'button[aria-label*="Send"]', '[aria-label="Send message"]'];
    result.stops   = ['button[aria-label*="Stop"]', '.stop-button', '[aria-label*="Stop"]'];
    result.spinner = ['.beating-circle', '.generating-loader'];

  } else if (host.includes('copilot.microsoft.com') || host.includes('bing.com')) {
    result.inputs  = ['textarea', '#searchbox', 'div[contenteditable="true"]'];
    result.buttons = ['button[aria-label*="Submit"]', 'button[aria-label*="Send"]', '.send-icon'];
    result.stops   = ['button[id*="stop"]', 'button[aria-label*="Stop"]'];

  } else if (host.includes('poe.com')) {
    result.inputs  = ['textarea[placeholder*="message"]', 'textarea', 'div[contenteditable="true"]'];
    result.buttons = ['button[class*="SendMessageButton"]', 'button[aria-label*="Send"]'];
    result.stops   = ['button[class*="StopMessageButton"]', 'button[aria-label*="Stop"]'];

  } else if (host.includes('character.ai')) {
    result.inputs  = ['textarea', 'div[contenteditable="true"]'];
    result.buttons = ['button[aria-label*="Send"]', 'button[type="submit"]'];
    result.stops   = ['button[aria-label*="Stop"]', 'button[class*="stop"]'];

  } else {
    // Generic fallback
    result.inputs  = ['textarea', 'div[contenteditable="true"]', '[role="textbox"]'];
    result.buttons = ['button[type="submit"]', 'button[aria-label*="Send"]', '.send-button'];
    result.stops   = ['button[aria-label*="Stop"]', '.stop-button'];
  }

  return result;
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
